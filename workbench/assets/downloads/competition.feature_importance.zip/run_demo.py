"""Run a complete local recipe; capture its actual figures in pastel-girl."""
from pathlib import Path
import os, sys, json, runpy, traceback, shutil, hashlib

ROOT = Path(__file__).resolve().parent
tid = json.loads((ROOT/'metadata.json').read_text(encoding='utf8'))['id']
folder = ROOT / 'output'
folder.mkdir(parents=True, exist_ok=True)
(folder / 'figures').mkdir(exist_ok=True)
(folder / '.vivid').mkdir(exist_ok=True)
(folder / '.vivid/config.json').write_text('{"palette":"pastel-girl","language":"zh"}', encoding='utf8')
os.chdir(folder)
os.environ.update(VIVID_WORKSPACE=str(folder), MPLBACKEND='Agg')
chrome=Path('C:/Program Files/Google/Chrome/Application/chrome.exe')
if chrome.is_file(): os.environ.setdefault('BROWSER_PATH',str(chrome))
sys.path[:0] = [str(ROOT), str(ROOT / '_utils')]
if tid in ['empirical.moran_scatter', 'empirical.lisa_map', 'competition.china_choropleth']:
    (folder / '_utils').mkdir(exist_ok=True)
    shutil.copy2(ROOT / '_utils/china_provinces.geojson', folder / '_utils/china_provinces.geojson')

import numpy as np
np.random.seed(20260915)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from _utils import plot_utils as pu
pu.setup_style()
import plotly.graph_objects as go
original_save = Figure.savefig
exports, seen = [], []
def export(fig, *args, **kwargs):
    if any(fig is item for item in seen):
        return
    seen.append(fig)
    path = folder / f'{len(exports)+1:02d}.png'
    if isinstance(fig, go.Figure):
        fig.update_layout(width=1000, height=760, font=dict(family='Microsoft YaHei', size=13))
        fig.write_image(str(path), scale=1.7)
    else:
        from matplotlib.text import Text
        for text in fig.findobj(match=Text):
            text.set_fontfamily(list(dict.fromkeys(text.get_fontfamily()+['Microsoft YaHei','DejaVu Sans','Segoe UI Symbol'])))
        original_save(fig, path, dpi=165, bbox_inches='tight', pad_inches=.15, facecolor='white')
    exports.append(path.name)

pu.save_fig = export
pu._save = export
plt.show = lambda *args, **kwargs: [export(plt.figure(n)) for n in plt.get_fignums()]
go.Figure.show = export
source = ROOT / 'preview.py'
result = dict(id=tid, palette='pastel-girl', source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
try:
    sys.argv = [str(source)]
    if tid == 'template.sem_violin_pearson':
        ns = runpy.run_path(str(source), run_name='gallery_sem')
        import pandas as pd
        rng=np.random.default_rng(109); n=250; order=ns['DEFAULT_ORDER']
        latent=rng.normal(size=(n,3)); loadings=rng.normal(0,.4,(3,len(order)))
        scored=pd.DataFrame(np.clip(4+latent@loadings+rng.normal(0,.65,(n,len(order))),1,7),columns=order)
        scored.to_csv(folder/'synthetic_scores.csv',index=False)
        paths=ns['draw_plots'](scored,ns['residualize_each_variable'](scored,order),scored.corr(),ns['p_values'](scored,order),order,folder,'sem')
        shutil.copy2(paths['combined_png'],folder/'01.png')
        exports.append('01.png')
    else:
        Figure.savefig = export
        if tid.startswith('template.shap_'):
            sys.argv += ['--mode', tid.split('_')[-1], '--demo', '--output', 'figures/demo']
        runpy.run_path(str(source), run_name='__main__')
        for n in plt.get_fignums():
            fig=plt.figure(n)
            if fig.axes: export(fig)
    result.update(status='ok' if exports else 'no_output', exports=exports)
except BaseException:
    result.update(status='failed', error=traceback.format_exc())
    print(result['error'])
(folder/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
plt.close('all')
print(tid, result['status'], len(exports))
sys.exit(0 if result['status']=='ok' else 1)

# ICE个体响应与PDP组合

模板：`advanced.ice_pdp`。预览配色：粉彩少女。

## 直接运行示例

解压到普通文件夹，安装 Python 3.10+。在该目录打开终端：

```sh
python -m pip install -r requirements.txt
python run_demo.py
```

生成的图片在 `output/`。三维 Plotly 模板还需要本机 Chrome；非 Windows 系统可通过 BROWSER_PATH 指定 Chrome 可执行文件。字体优先使用微软雅黑，其他系统请安装中文字体或修改字体列表。

## 改成自己的数据

- `preview.py`：完整绘图源码，已适配粉彩少女。在这个文件里替换示例数据，保留绘图结构。
- `original.py`：库内原始源码，按字节原样保存，便于核对。原版可能使用其他颜色。
- `run_demo.py`：设置本地粉彩配置并运行源码，将实际图像保存到 output；完整组合模板调用各自的示例入口。
- `gallery_theme.py` 与 `_utils/`：配色和绘图辅助模块。
- `card.md`：适用数据与视觉说明。`recipe.md`（如有）：模板完整使用说明。
- `preview.diff` / `metadata.json`：预览适配差异与来源校验值。

所有预览都使用模板示例数据。SHAP 演示使用合成模型及对应的解析 SHAP；用于实际分析时应换成真实模型输出，不能直接当作研究结果。

特征变化如何影响个体及平均预测？

## 图内语言 / Figure language

默认中文。运行 `python run_demo.py --language en` 使用英文固定标签和字体；`--labels labels.json` 提供原文到英文显示名的 JSON 映射。原始数据和绘图结构保持不变，未知名称会保留并提示。修改源码直接运行时，在保存前使用 `_utils.figure_language.localize_figure`（Plotly 使用 `localize_plotly`），或按 Skill 指导修改显示文字。

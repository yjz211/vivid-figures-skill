# 环形分组柱状对比图

安装 `pip install -r requirements.txt` 后运行 `python run_demo.py`，生成 output/ 下 PNG、PDF、SVG。

图中示例标签和读数来自参考图片，未独立核验原实验。默认按任务独立缩放柱长，只用于组内比较。

在 preview.py 的 demo_data() 替换数据，或使用 `python preview.py --help` 查看 CSV 参数。完整数据要求见 card.md。

## 图内语言 / Figure language

默认中文。运行 `python run_demo.py --language en` 使用英文固定标签和字体；`--labels labels.json` 提供原文到英文显示名的 JSON 映射。原始数据和绘图结构保持不变，未知名称会保留并提示。修改源码直接运行时，在保存前使用 `_utils.figure_language.localize_figure`（Plotly 使用 `localize_plotly`），或按 Skill 指导修改显示文字。

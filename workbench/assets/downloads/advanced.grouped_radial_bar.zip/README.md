# 环形分组柱状对比图

安装 `pip install -r requirements.txt` 后运行 `python run_demo.py`，生成 output/ 下 PNG、PDF、SVG。

图中示例标签和读数来自参考图片，未独立核验原实验。默认按任务独立缩放柱长，只用于组内比较。

在 preview.py 的 demo_data() 替换数据，或使用 `python preview.py --help` 查看 CSV 参数。完整数据要求见 card.md。

from pathlib import Path
import argparse,json,os,runpy,sys
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--language',choices=['zh','en']);parser.add_argument('--labels',type=Path);args=parser.parse_args()
config=json.loads((root/'.vivid/config.json').read_text(encoding='utf8'))
if args.language:config['language']=args.language
if args.labels:config['english_labels']=json.loads(args.labels.read_text(encoding='utf8'))
(root/'.vivid/config.json').write_text(json.dumps(config,ensure_ascii=False),encoding='utf8')
os.chdir(root);os.environ['VIVID_WORKSPACE']=str(root)
sys.path.insert(0,str(root/'_utils'))
from matplotlib.figure import Figure
from matplotlib.text import Text
from figure_language import localize_figure,apply_figure_fonts
save=Figure.savefig
def export(fig,*a,**kw):
    language=config.get('language','zh')
    localize_figure(fig,language,config.get('english_labels',{}))
    apply_figure_fonts(fig,language)
    return save(fig,*a,**kw)
Figure.savefig=export
sys.argv=['preview.py','--output',str(root/'output/fig_grouped_radial_bar')]
runpy.run_path(str(root/'preview.py'),run_name='__main__')

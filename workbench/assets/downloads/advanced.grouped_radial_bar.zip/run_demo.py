from pathlib import Path
import os,runpy,sys
root=Path(__file__).resolve().parent
os.chdir(root)
os.environ['VIVID_WORKSPACE']=str(root)
sys.argv=['preview.py','--output',str(root/'output/fig_grouped_radial_bar')]
runpy.run_path(str(root/'preview.py'),run_name='__main__')

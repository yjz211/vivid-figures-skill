## 14. 三维网格曲面

用途：连续曲面色阶、白色横纵等值网格、三维坐标。

数据要求：规则网格 X、Y、Z。

来源：小明的代码美学；代码截图恢复与适配。截图中的若干 .mplstyle 文件未附带；使用源码可见色值、透明度和描边，加上可移植字体/白背景默认值。代码通过视觉读取及OCR辅助恢复，并局部适配，不是作者原始文件的逐字副本。

适配记录：恢复全部可见绘图层与示例数据；调整导入、缩进、标签或输出边距以兼容当前运行环境。；使用Plotly交互显示；预览通过Kaleido导出，画布和边距适配截图检查。3D PDF内部仍含栅格渲染。

```python
"""三维网格曲面
Restored/adapted from supplied screenshots [47].
Source: 小明的代码美学 (as shown in supplied screenshots).
This is a runnable restoration, not a byte-for-byte original source file.
See SOURCE.md for missing inputs and documented corrections.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize, to_hex
from matplotlib.cm import ScalarMappable
from pathlib import Path
# Missing .mplstyle files are replaced only by explicit, portable display defaults.
plt.rcParams.update({'font.sans-serif':['Microsoft YaHei','DejaVu Sans'],
 'axes.unicode_minus':False,'figure.facecolor':'white','axes.facecolor':'white',
 'axes.spines.top':False,'axes.spines.right':False,'font.size':9})
import plotly.graph_objects as go
rows, cols = 32, 22
x = np.linspace(-1, 1, cols)
y = np.linspace(-1.7, 1.3, rows)
X, Y = np.meshgrid(x, y)
Z = np.exp(-((X+.5)**2+(Y+.5)**2)/.7)*1.5 + np.exp(-((X-.5)**2+(Y-.5)**2)/.3)
colorscale_custom = [[0., '#2f648e'], [.5, '#e9d1ab'], [1., '#c3476a']]

fig=go.Figure(go.Surface(x=X,y=Y,z=Z,colorscale=colorscale_custom,contours={
 'x':dict(show=True,color='white',width=1,start=x.min(),end=x.max(),size=.1),
 'y':dict(show=True,color='white',width=1,start=y.min(),end=y.max(),size=.1)}))
fig.update_layout(scene=dict(xaxis_title='X',yaxis_title='Y',zaxis_title='Z'),margin=dict(l=0,r=0,t=0,b=0))
# Export-safe frame leaves room for outer 3D ticks.
fig.update_layout(margin=dict(l=30,r=30,t=30,b=35))
fig.update_layout(scene_camera=dict(eye=dict(x=1.65,y=1.65,z=1.5)))
fig.show()
```
